package com.itc.client.controller;

import java.util.List;

import javax.validation.Valid;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.itc.client.entity.Client;
import com.itc.client.exception.ClientException;
import com.itc.client.service.ClientService;
import com.itc.client.util.ClientUtil;

@Controller
public class ClientController {

	private static final Logger logger = LogManager.getLogger(ClientController.class);  

	@Autowired
	private ClientService clientService;



	@GetMapping("/search")
	public String searchAll(Client client,BindingResult result, Model model) {
		logger.info("searchAll---Start-"+client);


		//model.addAttribute("clients", clientRepository.findByFirstnameAndClientidAndMobilenumber(client.getFirstname(),client.getClientid(),client.getMobilenumber()));
		List<Client> clients = null;
		try {
			clients = clientService.fetchClients(client.getFirstName(),client.getMobileNumber(),client.getIdNumber());
		}catch(Exception e) {
			logger.info(e.getMessage());
		}

		model.addAttribute("clients",clients);
		client=new Client();

		logger.info("searchAll---End-");
		return "index"; 
	}


	@GetMapping("/")
	public String index(Client client, Model model) {
		logger.info("index---Start-");
		model.addAttribute("clients", clientService.fetchClients("","",""));		
		logger.info("index---end-");
		return "index"; 
	}



	@GetMapping("/new")
	public String landingNewUserForm(Client client,Model model) {
		logger.info("landing---Start-");
		model.addAttribute("clients", clientService.fetchClients("","",""));
		logger.info("landing---end-");
		return "add-client";
	}


	@GetMapping("/edit/{clientMapKey}")
	public String updateForm(@PathVariable("clientMapKey") Integer clientMapKey, Model model) {
		logger.info("-------updateForm------Start----"+clientMapKey);
		Client client =clientService.fetchClientByKey(clientMapKey);
		//List<Client> clientLst = clientService.fetchClients("","",idNumber);
		logger.info("---client----"+client);
		model.addAttribute("client", client);
		logger.info("-------updateForm------End----"+clientMapKey);
		return "update-client";
	}

	@GetMapping("/delete/{paramKey}")
	public String deleteUser(@PathVariable("paramKey") Integer paramKey, Model model) {
		logger.info("ClientController.deleteUser()--Start----:"+paramKey);
		//List<Client> clientLst = clientService.fetchClients("","",idNumber);
		clientService.deleteClient(paramKey);
		model.addAttribute("clients", clientService.fetchClients("","",""));
		logger.info("ClientController.deleteUser()--End----:");
		return "index"; 
	}

	@PostMapping("/addclient")
	public String addUser(@Valid Client client, BindingResult result, Model model) {
		logger.info("ClientController.addUser()--Start----:"+client);
		if (result.hasErrors()) {
			model.addAttribute("errorMessage", "Errors");
			return "add-client";
		}

		boolean isValidZaId =	ClientUtil.isValidIdNumber(client.getIdNumber());
		List<Client> clientDup =null;
		try {
			clientDup =	 clientService.fetchClients("","",client.getIdNumber());
		}catch(Exception e) {
			logger.info(e.getMessage());
		}
		List<Client> clientDupMobileNo =	null;
		try {
			clientDupMobileNo =	 clientService.fetchClients("",client.getMobileNumber(),"");
		}catch(Exception e) {
			logger.info(e.getMessage());
		}

		boolean idDuplicateClientId =clientService.isClientIdExists(client.getIdNumber()); 
		boolean  idDuplicateMobileNo =
				clientService.isMobileNumberExist(client.getMobileNumber());

		//	boolean idDuplicateClientId =	ClientUtil.checkForDuplicateClientId(client.getMobilenumber());
		//	boolean idDuplicateMobileNo =	ClientUtil.checkForDuplicateMobileNumber(client.getMobilenumber());

		if(!isValidZaId) {
			model.addAttribute("errorMessage", "Invalid South african Id");
			return "add-client";			
		}

		if(idDuplicateClientId  && idDuplicateMobileNo) {
			model.addAttribute("errorMessage", "Duplicate South african Id & Duplicate Mobile Number");
			return "add-client";
		}

		if(idDuplicateClientId  ) {
			model.addAttribute("errorMessage", "Duplicate South african Id");
			return "add-client";
		}

		if(idDuplicateMobileNo) {
			model.addAttribute("errorMessage", "Duplicate Mobile Number");
			return "add-client";
		}


		clientService.createClient(client);
		//List<Client> clientInDB = clientRepository.findByFirstname(client.getFirstname());
		//logger.info("---clientInDB--"+clientInDB);
		model.addAttribute("clients", clientService.fetchClients("","",""));
		logger.info("ClientController.addUser()--End----:"+client);
		return "index";
	}

	@PostMapping("/update/{paramIdNumber}")
	public String updateUser(@PathVariable("paramIdNumber") Integer paramMapKey, @Valid Client client, BindingResult result, Model model) {
		logger.info(paramMapKey+": idNumber---ClientController.updateUser()--Start----:"+client);
		if (result.hasErrors()) {
			client.setClientMapKey(paramMapKey);
			return "update-client";
		}




		//check for updated idnumber and mobile number exists are not

		boolean isValidZaId = ClientUtil.isValidIdNumber(client.getIdNumber());

		logger.info("---isValidZaId--updateUser--"+isValidZaId);

		List<Client> clientDup =null;
		try {
			clientDup =	 clientService.fetchClients("","",client.getIdNumber());
		}catch(Exception e) {
			logger.error(e.getMessage());
		}
		List<Client> clientDupMobileNo =	null;
		try {
			clientDupMobileNo =	 clientService.fetchClients("",client.getMobileNumber(),"");
		}catch(Exception e) {
			logger.error(e.getMessage());
		}

	

		boolean idDuplicateClientId =clientService.isClientIdExists(client.getIdNumber()); 
		boolean  idDuplicateMobileNo =
				clientService.isMobileNumberExist(client.getMobileNumber());

		logger.info("---idDuplicateClientId--updateUser--"+idDuplicateClientId);
		logger.info("---idDuplicateMobileNo--updateUser--"+idDuplicateMobileNo);


	

		if(!isValidZaId) { 
			model.addAttribute("errorMessage",
					"Invalid South african Id");
			return "update-client"; 
		}

		if(idDuplicateClientId && idDuplicateMobileNo ) { 			
			if((clientDup!=null && clientDup.size()>0) && (clientDupMobileNo!=null && clientDupMobileNo.size()>0)) {
				if( client.getIdNumber().equals(clientDup.get(0).getIdNumber()) && 
						client.getMobileNumber().equals(clientDupMobileNo.get(0).getMobileNumber()) ){
					model.addAttribute("errorMessage",
							"Duplicate South african Id & Duplicate Mobile Number"); 
					return	"update-client"; 
				}
			}


		}
		logger.info("---cliet from front end--updateUser--"+client);
		logger.info("---clientDup--updateUser--"+clientDup);
		logger.info("---clientDupMobileNo--updateUser--"+clientDupMobileNo);

		if(idDuplicateClientId ){

			if(clientDup!=null && clientDup.size()>0) {
				//if(! client.getIdNumber().equals(clientDup.get(0).getIdNumber())  && client.getClientMapKey()!=clientDup.get(0).getClientMapKey()) {
				if(client.getClientMapKey()!=clientDup.get(0).getClientMapKey()) {
					model.addAttribute("errorMessage", "Duplicate South african Id");
					return "update-client"; 
				}
			}

		}
		//&& (clientDup!=null && clientDup.size()>0) && client.getIdNumber().equals(clientDup.get(0).getIdNumber())
		if(idDuplicateMobileNo ) {
			if(clientDupMobileNo!=null && clientDupMobileNo.size()>0) {
				if( client.getClientMapKey()!=(clientDupMobileNo.get(0).getClientMapKey())) {
					model.addAttribute("errorMessage", "Duplicate Mobile Number"); 
					return "update-client"; 
				}
			}

		}

		logger.info("00000000000000000000 calling service update start");
		try {
			clientService.updateClient(paramMapKey,client);
		}catch(ClientException e) {
			logger.error(e.getMessage());
			model.addAttribute("errorMessage", e.getMessage());
		}


		//	}


		logger.info("00000000000000000000 calling service update end");
		model.addAttribute("clients", clientService.fetchClients("","",""));

		logger.info("ClientController.updateUser()--End----:"+client);
		return "index";
	}


}
