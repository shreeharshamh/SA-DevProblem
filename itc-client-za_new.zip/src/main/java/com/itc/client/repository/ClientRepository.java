package com.itc.client.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.itc.client.entity.Client;
import com.itc.client.exception.ClientException;

@Repository
public class ClientRepository {
	private static final Logger logger = LogManager.getLogger(ClientRepository.class);  

	//static Map<String, Client> clientMap = new HashMap<String, Client>();

	static Map<Integer, Client> clientMap = new HashMap<Integer, Client>();
	static int count = 0;
	static {
		count =count+1;
		Client input = new Client();
		input.setFirstName("Mahatma");
		input.setLastName("Gandhi");
		input.setMobileNumber("8754565356");
		input.setIdNumber("2001015800085");
		input.setAddress("Johannesburg");
		input.setClientMapKey(count);
		clientMap.put(count, input);

	}

	public List<Client> getBysearchParam(String firstName, String mobileNumber, String idNumber) throws ClientException{

		List<Client> clientList =null;

		// logical operations between  firstName mobileNumber mobileNumber  based on values provided in front end

		if((firstName!=null && !"".equalsIgnoreCase(firstName) )&& ( mobileNumber!=null && !"".equalsIgnoreCase(mobileNumber)) && ( idNumber!=null && !"".equalsIgnoreCase(idNumber))) {
			clientList =clientMap.entrySet().stream().filter(v -> firstName.equalsIgnoreCase(v.getValue().getFirstName())
					&& mobileNumber.equalsIgnoreCase(v.getValue().getMobileNumber())
					&& idNumber.equalsIgnoreCase(v.getValue().getIdNumber())
					)
					.map(x -> x.getValue()).collect(Collectors.toList());
		}else 	if((firstName!=null && "".equalsIgnoreCase(firstName) ) && ( idNumber!=null && !"".equalsIgnoreCase(idNumber))) {
			clientList =clientMap.entrySet().stream().filter(v -> firstName.equalsIgnoreCase(v.getValue().getFirstName())
					&& idNumber.equalsIgnoreCase(v.getValue().getIdNumber())
					)
					.map(x -> x.getValue()).collect(Collectors.toList());
		}	if((firstName!=null && !"".equalsIgnoreCase(firstName) )&& ( mobileNumber!=null && !"".equalsIgnoreCase(mobileNumber)) ) {
			clientList =clientMap.entrySet().stream().filter(v -> firstName.equalsIgnoreCase(v.getValue().getFirstName())
					&& mobileNumber.equalsIgnoreCase(v.getValue().getMobileNumber())					
					)
					.map(x -> x.getValue()).collect(Collectors.toList());
		}else 	if( ( mobileNumber!=null && !"".equalsIgnoreCase(mobileNumber)) && ( idNumber!=null && !"".equalsIgnoreCase(idNumber))) {
			clientList =clientMap.entrySet().stream().filter(v ->  mobileNumber.equalsIgnoreCase(v.getValue().getMobileNumber())
					&& idNumber.equalsIgnoreCase(v.getValue().getIdNumber())
					)
					.map(x -> x.getValue()).collect(Collectors.toList());
		}else if( ( mobileNumber!=null && !"".equalsIgnoreCase(mobileNumber)) ) {
			clientList =clientMap.entrySet().stream().filter(v ->  mobileNumber.equalsIgnoreCase(v.getValue().getMobileNumber())

					)
					.map(x -> x.getValue()).collect(Collectors.toList());
		}else if(  ( idNumber!=null && !"".equalsIgnoreCase(idNumber))) {
			clientList =clientMap.entrySet().stream().filter(v ->  idNumber.equalsIgnoreCase(v.getValue().getIdNumber())
					)
					.map(x -> x.getValue()).collect(Collectors.toList());
		}else if( (firstName!=null && !"".equalsIgnoreCase(firstName) )) {
			clientList =clientMap.entrySet().stream().filter(v ->  firstName.equalsIgnoreCase(v.getValue().getFirstName())

					)
					.map(x -> x.getValue()).collect(Collectors.toList());
		} /*
		 * else{ clientList =clientMap.entrySet().stream().filter(v ->
		 * firstName.equalsIgnoreCase(v.getValue().getFirstName()) ||
		 * mobileNumber.equalsIgnoreCase(v.getValue().getMobileNumber()) ||
		 * idNumber.equalsIgnoreCase(v.getValue().getIdNumber()) ) .map(x ->
		 * x.getValue()).collect(Collectors.toList()); }
		 */
		return clientList;
	}

	public List<Client> getByFirstName(String firstName) {
		List<Client>  clientList =clientMap.entrySet().stream().filter(v -> firstName.equalsIgnoreCase(v.getValue().getFirstName()))
				.map(x -> x.getValue()).collect(Collectors.toList());
		return clientList;
	}

	public Client getByMobileNumber(String mobileNumber) {
		Client  client =clientMap.entrySet().stream().filter(v -> mobileNumber.equals(v.getValue().getMobileNumber()))
				.map(Map.Entry::getValue).findFirst().orElse(null);
		return client;

	}

	public Client getByIdNumber(String idNumber) {

		Client  client =clientMap.entrySet().stream().filter(v -> idNumber.equals(v.getValue().getIdNumber()))
				.map(Map.Entry::getValue).findFirst().orElse(null);

		return client;

	}
	
	
	public Client getByClientMapKey(Integer clientMapKey) {

		Client  client =clientMap.entrySet().stream().filter(v -> clientMapKey.equals(v.getValue().getClientMapKey()))
				.map(Map.Entry::getValue).findFirst().orElse(null);

		return client;

	}

	public Client persist(Client client) {
		count =count+1;
		client.setClientMapKey(count);
		clientMap.put(count, client);
		return client;
	}

	public Client persistUpdate(int countKey ,Client client) {
		clientMap.put(countKey, client);
		return client;
	}

	public List<Client> getByAll() {
		List<Client>  clientList = clientMap.values().stream().collect(Collectors.toList());
		return clientList;
	}

	public void delete(int countKey ) {
		clientMap.remove(countKey);
	}
}
