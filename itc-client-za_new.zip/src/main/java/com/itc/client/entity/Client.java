package com.itc.client.entity;

import javax.validation.constraints.NotBlank;



public class Client {
    




	@NotBlank(message = "FirstName is required")
    private String firstName;    
    
   
    private String lastName;

    @NotBlank(message = "ClientId is required")
    private String idNumber;    
   
    private String address;
    @NotBlank(message = "Mobile No is required")
    private String mobileNumber;
    
  
    private Integer clientMapKey;

	
   
   



	public Client() {
		super();
	}




	@Override
	public String toString() {
		return "Client [firstName=" + firstName + ", lastName=" + lastName + ", idNumber=" + idNumber + ", address="
				+ address + ", mobileNumber=" + mobileNumber + ", clientMapKey=" + clientMapKey + "]";
	}








	
	 public Client(@NotBlank(message = "firstName is required") String firstName,
			@NotBlank(message = "lastName is required") String lastName,
			@NotBlank(message = "clientId is required") String idNumber, String address, String mobileNumber,
			@NotBlank(message = "clientMapKey is required") Integer clientMapKey) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.idNumber = idNumber;
		this.address = address;
		this.mobileNumber = mobileNumber;
		this.clientMapKey = clientMapKey;
	}






	public Integer getClientMapKey() {
		return clientMapKey;
	}






	public void setClientMapKey(Integer clientMapKey) {
		this.clientMapKey = clientMapKey;
	}






	public String getFirstName() {
		return firstName;
	}






	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}






	public String getLastName() {
		return lastName;
	}






	public void setLastName(String lastName) {
		this.lastName = lastName;
	}






	public String getIdNumber() {
		return idNumber;
	}






	public void setIdNumber(String idNumber) {
		this.idNumber = idNumber;
	}






	public String getAddress() {
		return address;
	}






	public void setAddress(String address) {
		this.address = address;
	}






	public String getMobileNumber() {
		return mobileNumber;
	}






	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}








}
