package com.itc.client.service;

import java.util.List;

import com.itc.client.entity.Client;
import com.itc.client.exception.ClientException;

public interface ClientService {
	public List<Client> fetchClients(String firstName, String mobileNumber, String idNumber) throws ClientException;

	public Client createClient(Client client);
	
	public Client updateClient(int clientMapKey,Client client) throws ClientException;
	
	public Client deleteClient(int clientMapKey);
	public  boolean isClientIdExists(String idNumber) ;
	
	public  boolean isMobileNumberExist(String mobileNumber);
	
	public Client fetchClientByKey(Integer clientMapKey);
	
	
}
