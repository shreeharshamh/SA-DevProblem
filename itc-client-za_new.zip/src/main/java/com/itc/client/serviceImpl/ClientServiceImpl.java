package com.itc.client.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.itc.client.entity.Client;
import com.itc.client.exception.ClientException;
import com.itc.client.repository.ClientRepository;
import com.itc.client.service.ClientService;
import com.itc.client.util.ClientUtil;

@Service
@Qualifier("clientService")
public class ClientServiceImpl implements ClientService {
	 private static final Logger logger = LogManager.getLogger(ClientServiceImpl.class);  

	@Autowired
	private ClientRepository repository;

	@Override
	public List<Client> fetchClients(String firstName, String mobileNumber, String idNumber) throws ClientException{
		
		//String search = filterSearchParam(firstName, mobileNumber, idNumber);
		
		logger.info("--firstName:"+firstName+":mobileNumber:"+mobileNumber+":idNumber:"+idNumber);
		List<Client> clients = null;
		if ((firstName == null || "".equalsIgnoreCase(firstName)) && (mobileNumber == null || "".equalsIgnoreCase(mobileNumber))  && (idNumber==null || "".equalsIgnoreCase(idNumber)) ) {
			clients = repository.getByAll();
		}else {
			clients = repository.getBysearchParam(firstName, mobileNumber, idNumber);
		}
		
			
		logger.info("ClientServiceImpl.fetch()--clients--:"+clients);
		if (clients.size() < 1)
			throw new ClientException("Client does not exist for given data");
		return clients;

	}

	@Override
	public Client createClient(Client client) {			
		client = repository.persist(client);
		return client;
	}

	@Override
	public Client updateClient(int clientkeyMap, Client client) throws ClientException {
		
		//if the client with idNumber and client param idnumber both are same get client and persists
		//else get the old client wirh idNumber and delete  ,later create with new client info
		Client clientFromDb =null;
		/*
		 * if(idNumber.equals(client.getIdNumber()) ){ clientFromDb =
		 * Optional.ofNullable(repository.getByIdNumber(idNumber.trim()))
		 * .orElseThrow(() -> new
		 * ClientException("Client does not exist for given id Number: " + idNumber));
		 * 
		 * }else { clientFromDb =
		 * Optional.ofNullable(repository.getByIdNumber(idNumber.trim())).get();
		 * repository.delete(clientFromDb); clientFromDb = new Client();
		 * clientFromDb.setIdNumber(client.getIdNumber()); }
		 */
		
		clientFromDb = Optional.ofNullable(repository.getByClientMapKey(clientkeyMap))
				.orElseThrow(() -> new ClientException("Client does not exist for given id Number: " + clientkeyMap));
		
		if (!isMobileNumberExist(client.getIdNumber())) {
			clientFromDb.setIdNumber(client.getIdNumber());
		}
		
		if (!isMobileNumberExist(client.getMobileNumber())) {
			clientFromDb.setMobileNumber(client.getMobileNumber());
		}
		clientFromDb.setFirstName(client.getFirstName());
		clientFromDb.setLastName(client.getLastName());
		clientFromDb.setAddress(client.getAddress());

		client = repository.persistUpdate(clientkeyMap,clientFromDb);
		return client;
	}

	
	private String filterSearchParam(String firstName, String mobileNumber, String idNumber) throws ClientException{
		if ((firstName != null && !firstName.isEmpty())) {
			return firstName;
		} else {
			if (idNumber != null && !idNumber.trim().isEmpty()) {
				Boolean isIdNumberValid =ClientUtil.isValidIdNumber(idNumber.trim());
				if(!isIdNumberValid)
					throw new ClientException("Please provide valid SA ID Number");
				return idNumber;
			} else {
				if (mobileNumber != null && !mobileNumber.trim().isEmpty())
					return mobileNumber;
				else
					return null;
			}

		}

	}

	@Override
	public Client deleteClient(int clientMapKey) {
		repository.delete(clientMapKey);
		return null;
	}
	
	

	public  boolean isClientIdExists(String idNumber) {
		return Optional.ofNullable(repository.getByIdNumber(idNumber.trim())).isPresent();
	}
	
	public boolean isMobileNumberExist(String mobileNumber) {
		return Optional.ofNullable(repository.getByMobileNumber(mobileNumber.trim())).isPresent();
	}

	@Override
	public Client fetchClientByKey(Integer clientMapKey) {
		// TODO Auto-generated method stub
		return repository.getByClientMapKey(clientMapKey);
	}


	
}