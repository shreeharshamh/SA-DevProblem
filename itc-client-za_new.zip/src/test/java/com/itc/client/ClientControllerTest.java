package com.itc.client;

import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.hasProperty;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.io.IOException;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
//import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.itc.client.entity.Client;
import com.itc.client.service.ClientService;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = ITCClientZaApplication.class)
@AutoConfigureMockMvc
public class ClientControllerTest {
	@Autowired
	private MockMvc mockMvc;

	@Spy
	private ClientService clientService;

	@Test
	public void should_create_valid_Client_and_return_created_status() throws Exception {
		Client input = createMockInput();
		input.setIdNumber("4001014800084");
		input.setMobileNumber("7865653544");
		Mockito.when(clientService.createClient(input)).thenReturn(input);
		mockMvc.perform(post("/addclient").accept(MediaType.APPLICATION_JSON)
				.contentType(MediaType.APPLICATION_JSON).content(mapToJson(input))).andExpect(status().is2xxSuccessful())
		.andExpect(view().name("add-client"));


	}

	@Test
	public void should_not_create_invalid_client_and_Negative() throws Exception {
		Client input = createMockInput();
		input.setFirstName(null);
		mockMvc.perform(post("/addclient").accept(MediaType.APPLICATION_JSON)
				.contentType(MediaType.APPLICATION_JSON).content(mapToJson(input)))
		.andExpect(view().name("add-client"))
		.andExpect(model().hasErrors());

		//errorMessage
		// .andExpect(model().attribute("errorMessage", hasProperty("Errors", 	is("First Name Can not be Empty."))));

	}

	@Test
	public void should_not_create_client_with_duplicate_mobile_number_Negative() throws Exception {
		Client input = createMockInput();
		input.setMobileNumber("8754565356");
		mockMvc.perform(post("/addclient").accept(MediaType.APPLICATION_JSON)
				.contentType(MediaType.APPLICATION_JSON).content(mapToJson(input))).andExpect(status().is2xxSuccessful())
		.andExpect(view().name("add-client"))
		.andExpect(model().hasErrors());

	}

	@Test
	public void should_not_create_client_with_invalid_SA_Id_number_Negative() throws Exception {
		Client input = createMockInput();
		input.setIdNumber("3803014800086");
		mockMvc.perform(post("/addclient").accept(MediaType.APPLICATION_JSON)
				.contentType(MediaType.APPLICATION_JSON).content(mapToJson(input)))
		.andExpect(status().is2xxSuccessful())
		.andExpect(view().name("add-client"))
		.andExpect(model().hasErrors());


	}

	@Test
	public void should_get_valid_client_with_ok_status() throws Exception {
		mockMvc.perform(get("/search?mobileNumber=8754565356").contentType(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk()).andExpect(content().contentType("text/html;charset=UTF-8"))

		.andExpect(status().is2xxSuccessful())
		.andExpect(view().name("index")) 
		.andExpect(model().hasNoErrors())
		.andExpect(model().attribute("clients", hasItem(
				allOf(
						hasProperty("mobileNumber", is("8754565356"))
						)
				)));

	}

	@Test
	public void should_no_clients_with_not_found_status() throws Exception {
		MvcResult result =	mockMvc.perform(get("/search?mobileNumber=8754565334").contentType(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk()).andExpect(content().contentType("text/html;charset=UTF-8"))
				.andExpect(status().is2xxSuccessful())
				.andExpect(view().name("index")) 
				.andExpect(model().hasNoErrors())
				.andReturn();
		String content = result.getResponse().getContentAsString();
		assertTrue(content.contains("No Clients"));
	}

	@Test
	public void should_update_client_positive() throws Exception {
		Client input = createMockInput();
		input.setIdNumber("3801014800084");
		input.setFirstName("steve");
		mockMvc.perform(post("/update/" + input.getIdNumber()).contentType(MediaType.APPLICATION_JSON)
				.content(mapToJson(input)))
		.andExpect(status().isOk()).andExpect(content().contentType("text/html;charset=UTF-8"))
		.andExpect(view().name("update-client")) 
		.andExpect(model().hasErrors())
		.andReturn();
	}

	@Test
	public void should_update_valid_client_negative() throws Exception {
		Client input = createMockInput();
		input.setFirstName("steve");
		mockMvc.perform(post("/update/" + input.getIdNumber()).contentType(MediaType.APPLICATION_JSON)
				.content(mapToJson(input)))
		.andExpect(status().is2xxSuccessful()).andExpect(content().contentType("text/html;charset=UTF-8"))
		.andExpect(view().name("update-client")) 
		.andExpect(model().hasErrors());
	}

	protected String mapToJson(Object obj) throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		return objectMapper.writeValueAsString(obj);
	}

	protected <T> T mapFromJson(String json, Class<T> clazz)
			throws JsonParseException, JsonMappingException, IOException {

		ObjectMapper objectMapper = new ObjectMapper();
		return objectMapper.readValue(json, clazz);
	}

	private Client createMockInput() {

		Client input = new Client();
		
		input.setFirstName("Mahatma");
		input.setLastName("Gandhi");
		input.setMobileNumber("8754565356");
		input.setIdNumber("2001015800085");
		input.setAddress("Johannesburg");
		

		return input;
	}
}
